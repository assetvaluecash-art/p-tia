from alembic import op

revision = "0002"
down_revision = "0001"


def upgrade():
    with op.batch_alter_table("payments") as batch_op:
        batch_op.drop_column("reference")


def downgrade():
    pass
